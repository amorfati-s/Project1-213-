/**
 * This is the driver class with the main method that calls the run method in Kiosk.java
 *
 * @author Siddhi Kasera, Sonal Madhok
 **/
public class RunProject1 {
    public static void main(String[] args) {
        new Kiosk().run();
    }
}